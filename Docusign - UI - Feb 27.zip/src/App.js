import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./components/Login";
import Inbox from "./components/Inbox";
import Sent from "./components/Sent";
import DocuSignApp from "./components/DocuSignApp";
import Layout from "./components/Layout";
import ThankYou from "./components/ThankYou";
import Waiting from "./components/Waiting";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        {/* Protected Routes inside Layout */}
        <Route path="/dashboard" element={<Layout />}>
          <Route path="inbox" element={<Inbox />} />
          <Route path="sent" element={<Sent />} />
          <Route path="docusignapp" element={<DocuSignApp />} />
          <Route path="waiting" element={<Waiting/>} />
         
        </Route>
        <Route path="ThankYou" element={<ThankYou/>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
