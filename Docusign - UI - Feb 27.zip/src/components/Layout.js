import React, { useEffect, useState } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import "./Layout.css";

const Layout = () => {
  const navigate = useNavigate();
  const userEmail = localStorage.getItem("userEmail"); // Get stored email

  const handleLogout = () => {
    localStorage.removeItem("userEmail"); // Clear stored email
    navigate("/"); // Redirect to login page
  };

  return (
    <div className="layout">
      {/* Sidebar */}
      <nav className="sidebar">
        {userEmail && (
          <div className="user-info">
            Logged in as: <strong>{userEmail}</strong>
          </div>
        )}

        <ul>
          <li><Link to="/dashboard/inbox">Inbox</Link></li>
          <li><Link to="/dashboard/sent">Sent</Link></li>
          <li><Link to="/dashboard/docusignapp">Upload Document</Link></li>
          <li><Link to="/dashboard/waiting">Waiting for Others</Link></li>
        </ul>
        <button className="logout-btn" onClick={handleLogout}>Logout</button>
      </nav>

      {/* Main Content */}
      <div className="content">
        <Outlet />
      </div>
    </div>
  );
};

export default Layout;