import { useNavigate } from "react-router-dom";

const ThankYou = () => {
  const navigate = useNavigate();

  return (
    <div className="center-container">
      <div className="center-box">
        <h1 className="text-3xl font-bold text-green-600">Thank you for signing!</h1>
      </div>
    </div>
  );
};

export default ThankYou;


