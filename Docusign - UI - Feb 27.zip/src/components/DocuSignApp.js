



// import { useState } from "react";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import "./DocuSignApp.css";

// const DocuSignApp = () => {
//   const [file, setFile] = useState(null);
//   const [usernames, setUsernames] = useState([""]);
//   const [message, setMessage] = useState("");
//   const [loading, setLoading] = useState(false);
//   const navigate = useNavigate();

//   const handleFileChange = (event) => {
//     setFile(event.target.files[0]);
//   };

//   const handleUsernameChange = (index, event) => {
//     const newUsernames = [...usernames];
//     newUsernames[index] = event.target.value;
//     setUsernames(newUsernames);
//   };

//   const addUsernameField = () => {
//     setUsernames([...usernames, ""]);
//   };

//   const removeUsernameField = (index) => {
//     if (usernames.length > 1) {
//       setUsernames(usernames.filter((_, i) => i !== index));
//     }
//   };

//   const handleUpload = async () => {
//     if (!file) {
//       setMessage("Please select a file.");
//       return;
//     }

//     const validUsernames = usernames.filter((name) => name.trim() !== "");
//     if (validUsernames.length === 0) {
//       setMessage("Please enter at least one username.");
//       return;
//     }

//     const userEmail = localStorage.getItem("userEmail");
//     let apiUrl = "http://localhost:5043/api/DocuSign/upload-documents";

//     if (userEmail === "docusign916@gmail.com") {
//       apiUrl = "http://localhost:5043/api/DocuSign/upload-document";
//     } else if (userEmail === "gangatharannadarajan@gmail.com") {
//       apiUrl = "http://localhost:5043/api/DocuSign/upload-documentss";
//     }

//     const formData = new FormData();
//     formData.append("file", file);
//     validUsernames.forEach((usernames) => {
//       formData.append("usernames[]", usernames);
//     });

//     setLoading(true);

//     try {
//       const response = await axios.post(apiUrl, formData);

//       if (response.status === 200) {
//         setMessage("✅ Document uploaded successfully!");
//       } else {
//         setMessage("❌ Failed to upload document. Please try again.");
//       }
//     } catch (error) {
//       console.error("Upload Error:", error);
//       setMessage("❌ Error uploading document: " + (error.response?.data || error.message));
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div style={{ textAlign: "center", marginTop: "20px" }}>
//       <h2>Upload Document</h2>

//       {usernames.map((username, index) => (
//         <div key={index} style={{ marginBottom: "10px" }}>
//           <input
//             type="text"
//             placeholder="Enter username"
//             value={username}
//             onChange={(event) => handleUsernameChange(index, event)}
//             style={{
//               display: "block",
//               width: "100%",
//               maxWidth: "300px",
//               padding: "5px",
//               margin: "auto",
//             }}
//           />
          
//         </div>
//       ))}

//       <button onClick={addUsernameField} style={{ marginBottom: "10px" }}>➕ Add Username</button>

//       <input type="file" onChange={handleFileChange} />
//       <button onClick={handleUpload} style={{ marginLeft: "10px" }} disabled={loading}>
//         {loading ? "Uploading..." : "Upload"}
//       </button>

//       {loading && <div className="spinner"></div>}

//       {message && (
//         <p
//           style={{
//             color: message.includes("successfully") ? "green" : "red",
//             fontWeight: "bold",
//             marginTop: "10px",
//           }}
//         >
//           {message}
//         </p>
//       )}
//     </div>
//   );
// };

// export default DocuSignApp;



import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./DocuSignApp.css";

const DocuSignApp = () => {
  const [file, setFile] = useState(null);
  const [usernames, setUsernames] = useState([""]);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUsernameChange = (index, event) => {
    const newUsernames = [...usernames];
    newUsernames[index] = event.target.value;
    setUsernames(newUsernames);
  };

  const addUsernameField = () => {
    setUsernames([...usernames, ""]);
  };

  const removeUsernameField = (index) => {
    if (usernames.length > 1) {
      setUsernames(usernames.filter((_, i) => i !== index));
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage("Please select a file.");
      return;
    }

    const validUsernames = usernames.filter((name) => name.trim() !== "");
    if (validUsernames.length === 0) {
      setMessage("Please enter at least one username.");
      return;
    }

    const userEmail = localStorage.getItem("userEmail");
    let apiUrl = "http://localhost:5043/api/DocuSign/upload-documents";

    if (userEmail === "docusign916@gmail.com") {
      apiUrl = "http://localhost:5043/api/DocuSign/upload-document";
    } else if (userEmail === "gangatharannadarajan@gmail.com") {
      apiUrl = "http://localhost:5043/api/DocuSign/upload-documentss";
    }

    const formData = new FormData();
    formData.append("file", file);
    validUsernames.forEach((username) => {
      formData.append("usernames[]", username);
    });

    setLoading(true);

    try {
      const response = await axios.post(apiUrl, formData);

      if (response.status === 200) {
        setMessage("✅ Document uploaded successfully!");
      } else {
        setMessage("❌ Failed to upload document. Please try again.");
      }
    } catch (error) {
      console.error("Upload Error:", error);
      setMessage("❌ Error uploading document: " + (error.response?.data || error.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <h2>Upload Document</h2>

      <button onClick={addUsernameField} style={{ marginBottom: "10px" }}>
        ➕ Add Recipient
      </button>

      {usernames.map((username, index) => (
        <div key={index} className="input-container">
          <input
            type="text"
            placeholder="Enter username"
            value={username}
            onChange={(event) => handleUsernameChange(index, event)}
            className="input-box"
            // style={{ marginLeft:"10px"}}
          />
          <br />
          
          <button onClick={() => removeUsernameField(index)} className="remove-btn">
            ❌
          </button>
        </div>
      ))}
        
        <input type="file" onChange={handleFileChange} className="file-input" />

      <button onClick={handleUpload} disabled={loading} className="upload-btn">
        {loading ? "Uploading..." : "Upload"}
      </button>

      {loading && <div className="spinner"></div>}

      {message && (
        <p
          style={{
            color: message.includes("successfully") ? "green" : "red",
            fontWeight: "bold",
            marginTop: "10px",
          }}
        >
          {message}
        </p>
      )}
    </div>
  );
};

export default DocuSignApp;
