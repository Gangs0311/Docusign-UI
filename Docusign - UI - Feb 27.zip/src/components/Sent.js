import { useEffect, useState } from "react";
import axios from "axios";
import "./Sent.css";

const Sent = () => {
  const [envelopes, setEnvelopes] = useState([]);
  const userEmail = localStorage.getItem("userEmail");
  let apiUrl = "http://localhost:5043/api/Sent/Sents"; // Default API

  if (userEmail === "docusign916@gmail.com") {
    apiUrl = "http://localhost:5043/api/Sent/Sent"; // Different API for this user
  }
  else if (userEmail === "gangatharannadarajan@gmail.com") {
    apiUrl = "http://localhost:5043/api/Sent/Sentss";
  }

  useEffect(() => {
    axios
      .get(apiUrl)
      .then((response) => {
        setEnvelopes(response.data?.envelopes || response.data || []);
      })
      .catch((error) => console.error("Error fetching envelopes:", error));
  }, []);

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      <div
        style={{
          width: "100%",
          margin: "auto",
          maxHeight: "700px",
          overflowY: "auto",
          border: "1px solid black",
          position: "relative",
        }}
      >
        {envelopes.length > 0 ? (
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
            }}
          >
            <thead
              style={{
                position: "sticky",
                top: 0,
                backgroundColor: "#f2f2f2",
                zIndex: 1000,
              }}
            >
              <tr>
                <th style={{ border: "1px solid black", padding: "10px" }}>Sender Name</th>
                <th style={{ border: "1px solid black", padding: "10px" }}>Sender Email</th>
                <th style={{ border: "1px solid black", padding: "10px" }}>Email Subject</th>
                <th style={{ border: "1px solid black", padding: "10px" }}>Envelope ID</th>
                <th style={{ border: "1px solid black", padding: "10px" }}>Status</th>
                <th style={{ border: "1px solid black", padding: "10px" }}>Created Date</th>
              </tr>
            </thead>
            <tbody>
              {envelopes.map((item, index) => {
                let senderName = "N/A";
                let senderEmail = "N/A";

                if (userEmail === "docusign916@gmail.com") {
                  senderName = "Docu Sign";
                  senderEmail = "docusign916@gmail.com";
                } else if (userEmail === "npgsganga002@gmail.com") {
                  senderName = "Gangatharan N";
                  senderEmail = "npgsganga002@gmail.com";
                }
                else if (userEmail === "gangatharannadarajan@gmail.com") {
                  senderName = "Gangatharan N";
                  senderEmail = "gangatharannadarajan@gmail.com";
                }

                return (
                  <tr key={index}>
                    <td style={{ border: "1px solid black", padding: "10px" }}>{senderName}</td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>{senderEmail}</td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {item.emailSubject || "N/A"}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {item.envelopeId || "N/A"}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {item.status || "N/A"}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {item.createdDateTime
                        ? new Date(item.createdDateTime).toLocaleString()
                        : "N/A"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <p>No messages found.</p>
        )}
      </div>
    </div>
  );
};

export default Sent;

