import { useEffect, useState } from "react";
import axios from "axios";
import "./Inbox.css";

const Inbox = () => {
  const [inbox, setInbox] = useState([]);
  const [signingUrl, setSigningUrl] = useState(null);
  const [showThankYou, setShowThankYou] = useState(false);
  const [userEmail, setUserEmail] = useState(localStorage.getItem("userEmail"));

  useEffect(() => {
    let apiUrl = "http://localhost:5043/api/Inbox/Inbox";

    if (userEmail === "docusign916@gmail.com") {
      apiUrl = "http://localhost:5043/api/Inbox/Inboxs";
    }
    else if (userEmail ==="gangatharannadarajan@gmail.com"){
      apiUrl = "http://localhost:5043/api/Inbox/Inboxss";
    }

    axios
      .get(apiUrl)
      .then((response) => setInbox(response.data))
      .catch((error) => console.error("Error fetching inbox:", error));
  }, [userEmail]);

  const handleSignDocument = async (envelopeId) => {
    let signingUrlApi = "";

    if (userEmail === "docusign916@gmail.com") {
      signingUrlApi = `http://localhost:5043/api/Inbox/GetSigningUrls?envelopeId=${envelopeId}`;
    } else if (userEmail === "npgsganga002@gmail.com") {
      signingUrlApi = `http://localhost:5043/api/Inbox/GetSigningUrl?envelopeId=${envelopeId}`;
    }else if (userEmail === "gangatharannadarajan@gmail.com") {
      signingUrlApi = `http://localhost:5043/api/Inbox/GetSigningUrlss?envelopeId=${envelopeId}`;
    } 
    else {
      alert("Unauthorized user!");
      return;
    }

    try {
      const signingResponse = await axios.get(signingUrlApi);
      if (signingResponse.data && signingResponse.data.url) {
        setSigningUrl(signingResponse.data.url);
        setShowThankYou(false);
      } else {
        alert("Signing URL not available.");
      }
    } catch (error) {
      console.error("Error fetching signing URL:", error);
    }
  };

  return (
    <div>
      {signingUrl ? (
        <div>
          {!showThankYou ? (
            <iframe
              src={signingUrl}
              width="100%"
              height="660px"
              style={{ border: "1px solid black" }}
              sandbox="allow-scripts allow-same-origin"
            ></iframe>
          ) : (
            <h2 style={{ textAlign: "center", marginTop: "20px", color: "green" }}>
              Thank you for signing!
            </h2>
          )}
          <br />
          <button
            onClick={() => {
              setSigningUrl(null);
              setTimeout(() => {
                window.location.reload();
              });
            }}
            style={{
              padding: "10px",
              backgroundColor: "#007bff",
              color: "white",
              borderRadius: "5px",
              cursor: "pointer",
              marginBottom: "10px",
            }}
          >
            Close
          </button>
        </div>
      ) : (
        <div
          style={{
            width: "100%",
            margin: "auto",
            maxHeight: "700px",
            overflowY: "auto",
            border: "1px solid black",
            position: "relative",
          }}
        >
          {inbox.length > 0 ? (
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
              }}
            >
              <thead
                style={{
                  position: "sticky",
                  top: 0,
                  backgroundColor: "#f2f2f2",
                  zIndex: 1000,
                }}
              >
                <tr>
                  <th style={{ border: "1px solid black", padding: "10px" }}>
                    Email Subject
                  </th>
                  <th style={{ border: "1px solid black", padding: "10px" }}>
                    Envelope ID
                  </th>
                  <th style={{ border: "1px solid black", padding: "10px" }}>
                    Status
                  </th>
                  <th style={{ border: "1px solid black", padding: "10px" }}>
                    Created Date
                  </th>
                  <th style={{ border: "1px solid black", padding: "10px" }}>
                    Recipient Name
                  </th>
                  <th style={{ border: "1px solid black", padding: "10px" }}>
                    Recipient Email
                  </th>
                  <th style={{ border: "1px solid black", padding: "10px" }}>
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {inbox.map((msg, index) => (
                  <tr key={index}>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {msg.emailSubject}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {msg.envelopeId}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {msg.status}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {msg.createdDateTime}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {userEmail === "docusign916@gmail.com"
                        ? "Gangatharan N"
                        : "Docu Sign"}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      {userEmail === "docusign916@gmail.com"
                        ? "npgsganga002@gmail.com"
                        : "docusign916@gmail.com"}
                    </td>
                    <td style={{ border: "1px solid black", padding: "10px" }}>
                      <button
                        onClick={() => handleSignDocument(msg.envelopeId)}
                        style={{
                          padding: "10px",
                          backgroundColor: "#007bff",
                          color: "white",
                          borderRadius: "5px",
                          cursor: "pointer",
                        }}
                      >
                        <b>Sign</b>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No messages found.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Inbox;
